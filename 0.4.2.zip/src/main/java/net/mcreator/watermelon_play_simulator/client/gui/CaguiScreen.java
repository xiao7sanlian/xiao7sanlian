package net.mcreator.watermelon_play_simulator.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;

import net.mcreator.watermelon_play_simulator.world.inventory.CaguiMenu;
import net.mcreator.watermelon_play_simulator.procedures.Unlockdg13Procedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowlqzProcedure;
import net.mcreator.watermelon_play_simulator.network.CaguiButtonMessage;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

import java.util.HashMap;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class CaguiScreen extends AbstractContainerScreen<CaguiMenu> {
	private final static HashMap<String, Object> guistate = CaguiMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_upload_video;
	Button button_highly_recommended;
	Button button_court_votes;

	public CaguiScreen(CaguiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 300;
		this.imageHeight = 200;
	}

	private static final ResourceLocation texture = new ResourceLocation("watermelon_play_simulator_2:textures/screens/cagui.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		if (Unlockdg13Procedure.execute(entity))
			this.font.draw(poseStack, Component.translatable("gui.watermelon_play_simulator_2.cagui.label_skillswip"), 5, 60, -12829636);
		if (ShowlqzProcedure.execute(entity))
			this.font.draw(poseStack, Component.translatable("gui.watermelon_play_simulator_2.cagui.label_cooling"), 95, 15, -12829636);
	}

	@Override
	public void onClose() {
		super.onClose();
	}

	@Override
	public void init() {
		super.init();
		button_upload_video = Button.builder(Component.translatable("gui.watermelon_play_simulator_2.cagui.button_upload_video"), e -> {
			if (true) {
				WatermelonPlaySimulator2Mod.PACKET_HANDLER.sendToServer(new CaguiButtonMessage(0, x, y, z));
				CaguiButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 5, this.topPos + 6, 87, 20).build();
		guistate.put("button:button_upload_video", button_upload_video);
		this.addRenderableWidget(button_upload_video);
		button_highly_recommended = Button.builder(Component.translatable("gui.watermelon_play_simulator_2.cagui.button_highly_recommended"), e -> {
			if (true) {
				WatermelonPlaySimulator2Mod.PACKET_HANDLER.sendToServer(new CaguiButtonMessage(1, x, y, z));
				CaguiButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 5, this.topPos + 33, 119, 20).build();
		guistate.put("button:button_highly_recommended", button_highly_recommended);
		this.addRenderableWidget(button_highly_recommended);
		button_court_votes = Button.builder(Component.translatable("gui.watermelon_play_simulator_2.cagui.button_court_votes"), e -> {
			if (Unlockdg13Procedure.execute(entity)) {
				WatermelonPlaySimulator2Mod.PACKET_HANDLER.sendToServer(new CaguiButtonMessage(2, x, y, z));
				CaguiButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 5, this.topPos + 69, 82, 20).build(builder -> new Button(builder) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (Unlockdg13Procedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		guistate.put("button:button_court_votes", button_court_votes);
		this.addRenderableWidget(button_court_votes);
	}
}
