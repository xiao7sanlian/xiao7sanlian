
package net.mcreator.watermelon_play_simulator.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import net.mcreator.watermelon_play_simulator.procedures.Unlockdg13Procedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowpsProcedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowmbhhsProcedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowmbProcedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowjndProcedure;
import net.mcreator.watermelon_play_simulator.procedures.ShowhhsProcedure;
import net.mcreator.watermelon_play_simulator.procedures.IsPlayerInXgplaymnq2Procedure;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class ShowPiaoShuOverlay {
	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		int posX = w / 2;
		int posY = h / 2;
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level;
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		if (IsPlayerInXgplaymnq2Procedure.execute(entity)) {
			Minecraft.getInstance().font.draw(event.getPoseStack(),

					ShowpsProcedure.execute(entity), posX + -207, posY + -103, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(),

					ShowmbProcedure.execute(world), posX + -207, posY + -85, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(), Component.translatable("gui.watermelon_play_simulator_2.show_piao_shu.label_your_ticket"), posX + -207, posY + -112, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(), Component.translatable("gui.watermelon_play_simulator_2.show_piao_shu.label_target_tickets"), posX + -207, posY + -94, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(), Component.translatable("gui.watermelon_play_simulator_2.show_piao_shu.label_your_hui_he_shu"), posX + -207, posY + -76, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(),

					ShowhhsProcedure.execute(entity), posX + -207, posY + -67, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(), Component.translatable("gui.watermelon_play_simulator_2.show_piao_shu.label_target_hui_he_shu"), posX + -207, posY + -58, -1);
			Minecraft.getInstance().font.draw(event.getPoseStack(),

					ShowmbhhsProcedure.execute(world), posX + -207, posY + -49, -1);
			if (Unlockdg13Procedure.execute(entity))
				Minecraft.getInstance().font.draw(event.getPoseStack(), Component.translatable("gui.watermelon_play_simulator_2.show_piao_shu.label_your_skill_points"), posX + -207, posY + -40, -1);
			if (Unlockdg13Procedure.execute(entity))
				Minecraft.getInstance().font.draw(event.getPoseStack(),

						ShowjndProcedure.execute(entity), posX + -207, posY + -31, -1);
		}
	}
}
