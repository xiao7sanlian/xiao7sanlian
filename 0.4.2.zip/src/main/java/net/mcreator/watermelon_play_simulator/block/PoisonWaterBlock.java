
package net.mcreator.watermelon_play_simulator.block;

import net.minecraft.world.level.material.MaterialColor;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.watermelon_play_simulator.procedures.PoisonWaterDangShengWuWanJiaPengZhuangCiFangKuaiShiProcedure;
import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModFluids;

public class PoisonWaterBlock extends LiquidBlock {
	public PoisonWaterBlock() {
		super(() -> WatermelonPlaySimulator2ModFluids.POISON_WATER.get(), BlockBehaviour.Properties.of(Material.WATER, MaterialColor.WATER).strength(100f).noCollission().noLootTable());
	}

	@Override
	public void entityInside(BlockState blockstate, Level world, BlockPos pos, Entity entity) {
		super.entityInside(blockstate, world, pos, entity);
		PoisonWaterDangShengWuWanJiaPengZhuangCiFangKuaiShiProcedure.execute(entity);
	}
}
