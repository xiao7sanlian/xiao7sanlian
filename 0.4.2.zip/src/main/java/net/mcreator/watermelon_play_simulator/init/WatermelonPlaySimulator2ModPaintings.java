
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.entity.decoration.PaintingVariant;

import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<PaintingVariant> CHAPTER_1_BACKGROUND = REGISTRY.register("chapter_1_background", () -> new PaintingVariant(48, 32));
}
