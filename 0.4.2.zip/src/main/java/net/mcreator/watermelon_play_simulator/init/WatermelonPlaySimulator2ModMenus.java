
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.watermelon_play_simulator.world.inventory.NrbclqguiMenu;
import net.mcreator.watermelon_play_simulator.world.inventory.DgchooselevelMenu;
import net.mcreator.watermelon_play_simulator.world.inventory.DatasBookGuiMenu;
import net.mcreator.watermelon_play_simulator.world.inventory.CaguiMenu;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<MenuType<DgchooselevelMenu>> DGCHOOSELEVEL = REGISTRY.register("dgchooselevel", () -> IForgeMenuType.create(DgchooselevelMenu::new));
	public static final RegistryObject<MenuType<NrbclqguiMenu>> NRBCLQGUI = REGISTRY.register("nrbclqgui", () -> IForgeMenuType.create(NrbclqguiMenu::new));
	public static final RegistryObject<MenuType<CaguiMenu>> CAGUI = REGISTRY.register("cagui", () -> IForgeMenuType.create(CaguiMenu::new));
	public static final RegistryObject<MenuType<DatasBookGuiMenu>> DATAS_BOOK_GUI = REGISTRY.register("datas_book_gui", () -> IForgeMenuType.create(DatasBookGuiMenu::new));
}
