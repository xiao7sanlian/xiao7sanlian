
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.watermelon_play_simulator.block.Xgplaymnq2PortalBlock;
import net.mcreator.watermelon_play_simulator.block.PoisonWaterBlock;
import net.mcreator.watermelon_play_simulator.block.NotrealironblockBlock;
import net.mcreator.watermelon_play_simulator.block.NotRealBlockChuLiQiBlock;
import net.mcreator.watermelon_play_simulator.block.GanstoneBlock;
import net.mcreator.watermelon_play_simulator.block.ExpOreBlock;
import net.mcreator.watermelon_play_simulator.block.ExpBlockBlock;
import net.mcreator.watermelon_play_simulator.block.DragonlightBlock;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<Block> NOT_REAL_IRON_BLOCK = REGISTRY.register("not_real_iron_block", () -> new NotrealironblockBlock());
	public static final RegistryObject<Block> LIVER_STONE = REGISTRY.register("liver_stone", () -> new GanstoneBlock());
	public static final RegistryObject<Block> DRAGON_LIGHT = REGISTRY.register("dragon_light", () -> new DragonlightBlock());
	public static final RegistryObject<Block> XGPLAYMNQ_2_PORTAL = REGISTRY.register("xgplaymnq_2_portal", () -> new Xgplaymnq2PortalBlock());
	public static final RegistryObject<Block> POISON_WATER = REGISTRY.register("poison_water", () -> new PoisonWaterBlock());
	public static final RegistryObject<Block> NOT_REAL_BLOCK_PROCESSOR = REGISTRY.register("not_real_block_processor", () -> new NotRealBlockChuLiQiBlock());
	public static final RegistryObject<Block> EXP_BLOCK = REGISTRY.register("exp_block", () -> new ExpBlockBlock());
	public static final RegistryObject<Block> EXP_ORE = REGISTRY.register("exp_ore", () -> new ExpOreBlock());
}
