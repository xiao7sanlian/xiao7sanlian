
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.watermelon_play_simulator.fluid.types.PoisonWaterFluidType;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<FluidType> POISON_WATER_TYPE = REGISTRY.register("poison_water", () -> new PoisonWaterFluidType());
}
