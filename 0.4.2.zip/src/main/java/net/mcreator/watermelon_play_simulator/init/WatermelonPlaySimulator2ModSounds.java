
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<SoundEvent> SHOU_ZHAI = REGISTRY.register("shou_zhai", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("watermelon_play_simulator_2", "shou_zhai")));
}
