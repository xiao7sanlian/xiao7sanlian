
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.watermelon_play_simulator.client.gui.NrbclqguiScreen;
import net.mcreator.watermelon_play_simulator.client.gui.DgchooselevelScreen;
import net.mcreator.watermelon_play_simulator.client.gui.DatasBookGuiScreen;
import net.mcreator.watermelon_play_simulator.client.gui.CaguiScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class WatermelonPlaySimulator2ModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(WatermelonPlaySimulator2ModMenus.DGCHOOSELEVEL.get(), DgchooselevelScreen::new);
			MenuScreens.register(WatermelonPlaySimulator2ModMenus.NRBCLQGUI.get(), NrbclqguiScreen::new);
			MenuScreens.register(WatermelonPlaySimulator2ModMenus.CAGUI.get(), CaguiScreen::new);
			MenuScreens.register(WatermelonPlaySimulator2ModMenus.DATAS_BOOK_GUI.get(), DatasBookGuiScreen::new);
		});
	}
}
