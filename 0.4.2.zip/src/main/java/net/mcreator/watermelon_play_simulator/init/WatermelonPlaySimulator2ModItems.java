
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.watermelon_play_simulator.item.Xgplaymnq2Item;
import net.mcreator.watermelon_play_simulator.item.QiangLieTieJianItem;
import net.mcreator.watermelon_play_simulator.item.PoisonWaterItem;
import net.mcreator.watermelon_play_simulator.item.FaShiPingItem;
import net.mcreator.watermelon_play_simulator.item.FaShiPingCoolingItem;
import net.mcreator.watermelon_play_simulator.item.ExperienceItem;
import net.mcreator.watermelon_play_simulator.item.DiamondNuggetItem;
import net.mcreator.watermelon_play_simulator.item.DatasBookItem;
import net.mcreator.watermelon_play_simulator.item.DGstartItem;
import net.mcreator.watermelon_play_simulator.item.ControlAreaItem;
import net.mcreator.watermelon_play_simulator.item.BigironnuggetItem;
import net.mcreator.watermelon_play_simulator.item.BigDiamondNuggetItem;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

public class WatermelonPlaySimulator2ModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<Item> BIG_IRON_NUGGET = REGISTRY.register("big_iron_nugget", () -> new BigironnuggetItem());
	public static final RegistryObject<Item> NOT_REAL_IRON_BLOCK = block(WatermelonPlaySimulator2ModBlocks.NOT_REAL_IRON_BLOCK);
	public static final RegistryObject<Item> LIVER_STONE = block(WatermelonPlaySimulator2ModBlocks.LIVER_STONE);
	public static final RegistryObject<Item> DRAGON_LIGHT = block(WatermelonPlaySimulator2ModBlocks.DRAGON_LIGHT);
	public static final RegistryObject<Item> DIGE_SPAWN_EGG = REGISTRY.register("dige_spawn_egg", () -> new ForgeSpawnEggItem(WatermelonPlaySimulator2ModEntities.DIGE, -256, -6711040, new Item.Properties()));
	public static final RegistryObject<Item> DG_START = REGISTRY.register("dg_start", () -> new DGstartItem());
	public static final RegistryObject<Item> XGPLAYMNQ_2 = REGISTRY.register("xgplaymnq_2", () -> new Xgplaymnq2Item());
	public static final RegistryObject<Item> POISON_WATER_BUCKET = REGISTRY.register("poison_water_bucket", () -> new PoisonWaterItem());
	public static final RegistryObject<Item> FA_SHI_PING = REGISTRY.register("fa_shi_ping", () -> new FaShiPingItem());
	public static final RegistryObject<Item> FA_SHI_PING_COOLING = REGISTRY.register("fa_shi_ping_cooling", () -> new FaShiPingCoolingItem());
	public static final RegistryObject<Item> QIANG_LIE_TIE_JIAN = REGISTRY.register("qiang_lie_tie_jian", () -> new QiangLieTieJianItem());
	public static final RegistryObject<Item> DIAMOND_NUGGET = REGISTRY.register("diamond_nugget", () -> new DiamondNuggetItem());
	public static final RegistryObject<Item> BIG_DIAMOND_NUGGET = REGISTRY.register("big_diamond_nugget", () -> new BigDiamondNuggetItem());
	public static final RegistryObject<Item> EXPERIENCE = REGISTRY.register("experience", () -> new ExperienceItem());
	public static final RegistryObject<Item> NOT_REAL_BLOCK_PROCESSOR = block(WatermelonPlaySimulator2ModBlocks.NOT_REAL_BLOCK_PROCESSOR);
	public static final RegistryObject<Item> EXP_BLOCK = block(WatermelonPlaySimulator2ModBlocks.EXP_BLOCK);
	public static final RegistryObject<Item> CONTROL_AREA = REGISTRY.register("control_area", () -> new ControlAreaItem());
	public static final RegistryObject<Item> EXP_ORE = block(WatermelonPlaySimulator2ModBlocks.EXP_ORE);
	public static final RegistryObject<Item> DATAS_BOOK = REGISTRY.register("datas_book", () -> new DatasBookItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
