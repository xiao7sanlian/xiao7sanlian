
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class WatermelonPlaySimulator2ModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == WatermelonPlaySimulator2ModVillagerProfessions.NEW_VILLAGER.get()) {
			event.getTrades().get(1)
					.add(new BasicItemListing(new ItemStack(WatermelonPlaySimulator2ModItems.DIAMOND_NUGGET.get(), 20), new ItemStack(WatermelonPlaySimulator2ModItems.EXPERIENCE.get(), 15), new ItemStack(Blocks.OBSIDIAN), 12, 2, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(WatermelonPlaySimulator2ModItems.DIAMOND_NUGGET.get(), 40), new ItemStack(WatermelonPlaySimulator2ModItems.EXPERIENCE.get(), 30),
					new ItemStack(WatermelonPlaySimulator2ModItems.XGPLAYMNQ_2.get()), 1, 5, 0.05f));
			event.getTrades().get(2)
					.add(new BasicItemListing(new ItemStack(WatermelonPlaySimulator2ModItems.DIAMOND_NUGGET.get(), 40), new ItemStack(WatermelonPlaySimulator2ModItems.EXPERIENCE.get(), 25), new ItemStack(Items.EMERALD), 12, 10, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(WatermelonPlaySimulator2ModItems.DIAMOND_NUGGET.get(), 20), new ItemStack(WatermelonPlaySimulator2ModItems.EXPERIENCE.get(), 10),
					new ItemStack(WatermelonPlaySimulator2ModBlocks.DRAGON_LIGHT.get()), 12, 10, 0.05f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(WatermelonPlaySimulator2ModItems.BIG_DIAMOND_NUGGET.get(), 10), new ItemStack(WatermelonPlaySimulator2ModBlocks.EXP_BLOCK.get(), 10),
					new ItemStack(WatermelonPlaySimulator2ModItems.DG_START.get()), 1, 25, 0.05f));
		}
	}
}
