
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.watermelon_play_simulator.world.features.ores.GanstoneFeature;
import net.mcreator.watermelon_play_simulator.world.features.ores.ExpOreFeature;
import net.mcreator.watermelon_play_simulator.world.features.DigeHouseFeature;
import net.mcreator.watermelon_play_simulator.world.features.Chapter1and2Feature;
import net.mcreator.watermelon_play_simulator.world.features.Chapter1and2BarrierFeature;
import net.mcreator.watermelon_play_simulator.WatermelonPlaySimulator2Mod;

@Mod.EventBusSubscriber
public class WatermelonPlaySimulator2ModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, WatermelonPlaySimulator2Mod.MODID);
	public static final RegistryObject<Feature<?>> LIVER_STONE = REGISTRY.register("liver_stone", GanstoneFeature::new);
	public static final RegistryObject<Feature<?>> CHAPTER_1AND_2 = REGISTRY.register("chapter_1and_2", Chapter1and2Feature::new);
	public static final RegistryObject<Feature<?>> DIGE_HOUSE = REGISTRY.register("dige_house", DigeHouseFeature::new);
	public static final RegistryObject<Feature<?>> CHAPTER_1AND_2_BARRIER = REGISTRY.register("chapter_1and_2_barrier", Chapter1and2BarrierFeature::new);
	public static final RegistryObject<Feature<?>> EXP_ORE = REGISTRY.register("exp_ore", ExpOreFeature::new);
}
