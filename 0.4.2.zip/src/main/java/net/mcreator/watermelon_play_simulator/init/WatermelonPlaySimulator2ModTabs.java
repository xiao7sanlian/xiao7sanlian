
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.watermelon_play_simulator.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WatermelonPlaySimulator2ModTabs {
	@SubscribeEvent
	public static void buildTabContentsModded(CreativeModeTabEvent.Register event) {
		event.registerCreativeModeTab(new ResourceLocation("watermelon_play_simulator_2", "tadxgplaymnq_2"),
				builder -> builder.title(Component.translatable("item_group.watermelon_play_simulator_2.tadxgplaymnq_2")).icon(() -> new ItemStack(WatermelonPlaySimulator2ModItems.DG_START.get())).displayItems((parameters, tabData) -> {
					tabData.accept(WatermelonPlaySimulator2ModItems.BIG_IRON_NUGGET.get());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.NOT_REAL_IRON_BLOCK.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.LIVER_STONE.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.DRAGON_LIGHT.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModItems.DIGE_SPAWN_EGG.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.DG_START.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.XGPLAYMNQ_2.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.POISON_WATER_BUCKET.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.DIAMOND_NUGGET.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.BIG_DIAMOND_NUGGET.get());
					tabData.accept(WatermelonPlaySimulator2ModItems.EXPERIENCE.get());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.NOT_REAL_BLOCK_PROCESSOR.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.EXP_BLOCK.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModBlocks.EXP_ORE.get().asItem());
					tabData.accept(WatermelonPlaySimulator2ModItems.DATAS_BOOK.get());
				}).withSearchBar());
	}
}
