
package net.mcreator.watermelon_play_simulator.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModItems;
import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModFluids;
import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModFluidTypes;
import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModBlocks;

public abstract class PoisonWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> WatermelonPlaySimulator2ModFluidTypes.POISON_WATER_TYPE.get(), () -> WatermelonPlaySimulator2ModFluids.POISON_WATER.get(),
			() -> WatermelonPlaySimulator2ModFluids.FLOWING_POISON_WATER.get()).explosionResistance(100f).bucket(() -> WatermelonPlaySimulator2ModItems.POISON_WATER_BUCKET.get())
			.block(() -> (LiquidBlock) WatermelonPlaySimulator2ModBlocks.POISON_WATER.get());

	private PoisonWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends PoisonWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends PoisonWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
