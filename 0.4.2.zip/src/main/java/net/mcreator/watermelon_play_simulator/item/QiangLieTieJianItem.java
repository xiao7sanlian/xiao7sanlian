
package net.mcreator.watermelon_play_simulator.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;
import net.minecraft.network.chat.Component;

import net.mcreator.watermelon_play_simulator.procedures.QiangLieTieJianDangYouJianDianJiFangKuaiShiFangKuaiDeWeiZhiProcedure;

import java.util.List;

public class QiangLieTieJianItem extends Item {
	public QiangLieTieJianItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(Component.literal("\u4F7F\u7528\u4EE5\u83B7\u5F9750\u7968\uFF01"));
		list.add(Component.literal("\u65E0\u4EFB\u4F55\u51B7\u5374\uFF01"));
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		QiangLieTieJianDangYouJianDianJiFangKuaiShiFangKuaiDeWeiZhiProcedure.execute(context.getLevel(), context.getPlayer());
		return InteractionResult.SUCCESS;
	}
}
