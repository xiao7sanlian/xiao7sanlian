
package net.mcreator.watermelon_play_simulator.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModFluids;

public class PoisonWaterItem extends BucketItem {
	public PoisonWaterItem() {
		super(WatermelonPlaySimulator2ModFluids.POISON_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
