
package net.mcreator.watermelon_play_simulator.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BigironnuggetItem extends Item {
	public BigironnuggetItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
