
package net.mcreator.watermelon_play_simulator.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BigDiamondNuggetItem extends Item {
	public BigDiamondNuggetItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
