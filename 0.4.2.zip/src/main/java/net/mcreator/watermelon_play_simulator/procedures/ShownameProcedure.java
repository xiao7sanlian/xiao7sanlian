package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.entity.Entity;

public class ShownameProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		return entity.getDisplayName().getString();
	}
}
