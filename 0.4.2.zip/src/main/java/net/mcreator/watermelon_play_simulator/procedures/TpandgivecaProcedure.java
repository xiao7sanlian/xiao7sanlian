package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;
import net.mcreator.watermelon_play_simulator.init.WatermelonPlaySimulator2ModItems;

public class TpandgivecaProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = 5 * (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_lv + 15;
			entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.player_skill_point = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		{
			Entity _ent = entity;
			_ent.teleportTo(0, 256, 0);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(0, 256, 0, _ent.getYRot(), _ent.getXRot());
		}
		if (entity instanceof Player _player) {
			ItemStack _setstack = new ItemStack(WatermelonPlaySimulator2ModItems.CONTROL_AREA.get());
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
	}
}
