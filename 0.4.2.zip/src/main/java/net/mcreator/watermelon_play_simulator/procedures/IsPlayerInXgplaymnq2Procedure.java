package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

public class IsPlayerInXgplaymnq2Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity.level.dimension()) == (ResourceKey.create(Registries.DIMENSION, new ResourceLocation("watermelon_play_simulator_2:xgplaymnq_2"))) && entity.getY() == 256;
	}
}
