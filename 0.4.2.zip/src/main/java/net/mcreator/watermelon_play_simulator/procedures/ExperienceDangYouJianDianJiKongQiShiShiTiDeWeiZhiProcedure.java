package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;

public class ExperienceDangYouJianDianJiKongQiShiShiTiDeWeiZhiProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_experience + 1;
			entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.player_experience = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		itemstack.shrink(1);
	}
}
