package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;

public class DbupgradeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_experience >= 50
				* (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_lv - 25) {
			{
				double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_experience
						- (50 * (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_lv - 25);
				entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.player_experience = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_lv + 1;
				entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.player_lv = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
