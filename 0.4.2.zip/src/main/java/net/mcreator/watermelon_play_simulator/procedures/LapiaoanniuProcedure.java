package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;

public class LapiaoanniuProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_skill_point >= 20) {
			{
				double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_piaoshu + 500;
				entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.player_piaoshu = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_skill_point - 20;
				entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.player_skill_point = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).fashiping_lengqie > 0) {
				{
					double _setval = (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).fashiping_lengqie - 1;
					entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.fashiping_lengqie = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			NoAnniuProcedure.execute(world, entity);
		}
	}
}
