package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;

public class Unlockdg14Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return (entity.getCapability(WatermelonPlaySimulator2ModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new WatermelonPlaySimulator2ModVariables.PlayerVariables())).player_best_level > 3;
	}
}
