package net.mcreator.watermelon_play_simulator.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.watermelon_play_simulator.network.WatermelonPlaySimulator2ModVariables;

public class ShowmbhhsProcedure {
	public static String execute(LevelAccessor world) {
		return new java.text.DecimalFormat("##.##").format(WatermelonPlaySimulator2ModVariables.MapVariables.get(world).mubiao_huiheshu);
	}
}
